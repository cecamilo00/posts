import boto3
import re
import os

client = boto3.client('stepfunctions')

def get_account_id(arn):
    account_id = re.match(r"arn:aws:lambda:[a-z]{2}-[a-z]+-\d+:(\d+):.*", arn).group(1)
    return account_id

def lambda_handler(event, context):
    archivo = event['Records'][0]['s3']['object']['key']
    account_id = get_account_id(context.invoked_function_arn)
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    arn_step_function = os.getenv('STEPFUNCTIONARN')
    response = client.start_execution(stateMachineArn=arn_step_function,
    input='{"bucket": "' + bucket_name + '","cuenta": "' + account_id + '","carpeta": "'+ archivo + '"}')